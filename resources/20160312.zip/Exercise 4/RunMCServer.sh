java -Xmx1024M -Xms1024M -jar minecraft_server.1.9.jar nogui
