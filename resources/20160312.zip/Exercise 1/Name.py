#This program asks the user to type in their name
#and reads it back to them

name = raw_input("Please enter your name: ")
print "Hello", name
