#This is a simple program
print "Hello world!"
