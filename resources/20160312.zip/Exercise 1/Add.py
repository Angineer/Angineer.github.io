#This programs adds 2 numbers together
a=2
b=3
print "a plus b equals:"
print a+b
